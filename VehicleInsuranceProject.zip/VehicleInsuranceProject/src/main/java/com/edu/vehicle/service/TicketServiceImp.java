package com.edu.vehicle.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.edu.vehicle.entity.Ticket;
import com.edu.vehicle.error.TicketNotFoundException;
import com.edu.vehicle.repository.RegisterRepository;
import com.edu.vehicle.repository.TicketRepository;
import javax.websocket.DeploymentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class TicketServiceImp implements TicketService {

	@Autowired
	private TicketRepository ticketRepository;
	
	@Autowired
	private RegisterRepository registerRepository;
	
	@Override
	public void saveTicket(Ticket ticket) {
		
		ticketRepository.save(ticket);
	}
	@Override
	public List<Ticket> getTicketById(Long ticketId) throws TicketNotFoundException  {
		
		Optional<Ticket> vle=ticketRepository.findById(ticketId) ;
		
		 if(!vle.isPresent()) {
			 throw new TicketNotFoundException("Ticket Not Found");
		 }
		 Ticket vl=ticketRepository.findById(ticketId).get();
		 List<Ticket>l=new ArrayList<>();
		 l.add(vl);
		 return l;
		// return VehicleRepository.findById(insuranceId).get();
	}
	/*
	 
		
		List <Customer>l=new ArrayList<>();
		l.add(cst);
		return l;
	}

	 */
	@Override
	public void ticketDeleteById(Long ticketId) throws TicketNotFoundException  {
	
		Optional<Ticket> vle=ticketRepository.findById(ticketId) ;
		if(!vle.isPresent()) {
			 throw new TicketNotFoundException("Ticket Not Found");
		 }
		ticketRepository.deleteById(ticketId);
		
	}
	@Override
	public Ticket ticketUpdateById(Long ticketId, Ticket ticket) throws TicketNotFoundException {
		
		Optional<Ticket> vle=ticketRepository.findById(ticketId) ;
		Ticket vleDB;
		if(!vle.isPresent()) {
			 throw new TicketNotFoundException("Ticket Not Found");
		 }
		
		 else{
		        vleDB=ticketRepository.findById(ticketId).get();
				
				if(Objects.nonNull(ticket.getMovieName()) &&
				!"".equalsIgnoreCase(ticket.getMovieName())) {
					vleDB.setMovieName(ticket.getMovieName());
				}
				
				if(Objects.nonNull(ticket.getTicketClass()) &&
						!"".equalsIgnoreCase(ticket.getTicketClass())) {
							vleDB.setTicketClass(ticket.getTicketClass());
						}
				
				if(Objects.nonNull(ticket.getnTicket())) {
						vleDB.setnTicket(ticket.getnTicket());
						}
				
				if(Objects.nonNull(ticket.getTicketFormat()) &&
						!"".equalsIgnoreCase(ticket.getTicketFormat())) {
						vleDB.setTicketFormat(ticket.getTicketFormat());
						}
				
				if(Objects.nonNull(ticket.getShowDate())) {
						vleDB.setShowDate(ticket.getShowDate());
						}
				
				if(Objects.nonNull(ticket.getShowTime()) &&
						!"".equalsIgnoreCase(ticket.getShowTime())) {
						vleDB.setShowTime(ticket.getShowTime());
						}

		 	}
				return ticketRepository.save(vleDB);
		 	
	}
	@Override
	public List<Ticket> getAllTickets() {
		
		return ticketRepository.findAll();
	}
}
