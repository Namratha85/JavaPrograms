package com.edu.vehicle.service;

import java.util.List;

import com.edu.vehicle.entity.Ticket;

import com.edu.vehicle.error.TicketNotFoundException;



public interface TicketService {

	public void saveTicket(Ticket ticket);

	public List<Ticket> getTicketById(Long ticketId) throws TicketNotFoundException;

	public void ticketDeleteById(Long ticketId) throws TicketNotFoundException;

	public Ticket ticketUpdateById(Long ticketId, Ticket ticket) throws TicketNotFoundException;

	public List<Ticket> getAllTickets();
	


}