package com.edu.vehicle.error;

public class RegisterNotFoundException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RegisterNotFoundException(String s) {
		super(s);
	}

}
