package com.edu.vehicle.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.edu.vehicle.entity.Register;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
@Entity
public class Ticket {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private Long ticketId;
private String movieName;
private String ticketClass;
private int nTicket;
private String ticketFormat ;
private Date showDate;
private String showTime;

@JsonIgnore
public Ticket() {
	
}
@JsonCreator
public Ticket(@JsonProperty("ticketId") Long ticketId,
              @JsonProperty("movieName") String movieName,
              @JsonProperty("ticketClass") String ticketClass,
              @JsonProperty("nTicket") int nTicket,
              @JsonProperty("ticketFormat") String ticketFormat,
              @JsonProperty("showDate") Date showDate,
              @JsonProperty("showTime") String showTime) {
    this.ticketId = ticketId;
    this.movieName = movieName;
    this.ticketClass = ticketClass;
    this.nTicket = nTicket;
    this.ticketFormat = ticketFormat;
    this.showDate = showDate;
    this.showTime = showTime;
}
public Long getTicketId() {
	return ticketId;
}
public void setTicketId(Long ticketId) {
	this.ticketId = ticketId;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public String getTicketClass() {
	return ticketClass;
}
public void setTicketClass(String ticketClass) {
	this.ticketClass = ticketClass;
}
public int getnTicket() {
	return nTicket;
}
public void setnTicket(int nTicket) {
	this.nTicket = nTicket;
}
public String getTicketFormat() {
	return ticketFormat;
}
public void setTicketFormat(String ticketFormat) {
	this.ticketFormat = ticketFormat;
}
public Date getShowDate() {
	return showDate;
}
public void setShowDate(Date showDate) {
	this.showDate = showDate;
}
public String getShowTime() {
	return showTime;
}
public void setShowTime(String showTime) {
	this.showTime = showTime;
}
@Override
public String toString() {
	return "Vehicle [ticketId=" + ticketId + ", movieName=" + movieName + ", ticketClass=" + ticketClass + ", nTicket="
			+ nTicket + ", ticketFormat=" + ticketFormat + ", showDate=" + showDate + ", showTime=" + showTime + "]";
}

}

