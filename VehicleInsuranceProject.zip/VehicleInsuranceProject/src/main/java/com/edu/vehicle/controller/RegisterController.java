package com.edu.vehicle.controller;

import java.util.List;


import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.vehicle.entity.Register;
import com.edu.vehicle.error.RegisterNotFoundException;
import com.edu.vehicle.repository.RegisterRepository;
import com.edu.vehicle.repository.TicketRepository;
import com.edu.vehicle.service.RegisterService;
import com.edu.vehicle.service.TicketService;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class RegisterController {
@Autowired
private  RegisterService  registerService;

@Autowired
private TicketService ticketService;

@Autowired
private TicketRepository ticketRepository;
@Autowired
private RegisterRepository registerRepository;

//Insert RecordcustomerService

/*@PostMapping("/customer") // http://localhost:8889/customer
public ResponseEntity<Customer> addCustomer(@Valid @RequestBody Customer customer) {
	System.out.println("Inside customer addCustomer");
	Customer cob=customerService.addCustomer(customer);
 return new ResponseEntity<Customer>(cob, HttpStatus.CREATED);
}*/
@PostMapping("/customer")
public String addCustomer(@RequestBody Register register) {
	registerService.addRegister(register);
	return "Hi!" +register.getrFirstName()+" Registeration Successfully Completed";
}
//getCustomerById

@GetMapping("/customer/{registerId}")
public List<Register> getCustomerById(@PathVariable("registerId") Long registerId) throws RegisterNotFoundException {
	return registerService.getRegisterById(registerId);
}
//update
@PutMapping("/update/{registerId}")
public Register updateCustomerById(@PathVariable("registerId") Long registerId,@RequestBody Register register) throws RegisterNotFoundException {
	
	return registerService.updateRegisterById(registerId,register);
	
}
//delete 

@DeleteMapping("/customer/{registerId}")
public String deleteRegisterById(@PathVariable("registerId") Long registerId) throws RegisterNotFoundException {
	registerService.deleteRegisterById(registerId);
	return "customer Deleted";
}
//findAllCustomers
@GetMapping("/customers")
public List<Register> findAllRegister(){
	return registerService.findAllRegister();
}
//assign customer to vehicle
@ResponseBody
@PutMapping("/customerAssignVehicle/{registerId}/vehicle/{ticketId}")
public Register registerAssignTicket(@PathVariable Long registerId, @PathVariable Long ticketId) {
	  System.out.println("insuranceId customerAssignVehicle");
	return registerService.registerAssignTicket(registerId,ticketId);

}
}
