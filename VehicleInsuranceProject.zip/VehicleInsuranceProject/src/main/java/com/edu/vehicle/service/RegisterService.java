package com.edu.vehicle.service;

import java.util.List;

import com.edu.vehicle.entity.Register;
import com.edu.vehicle.error.RegisterNotFoundException;




public interface RegisterService {

public Register addRegister(Register register);

public List<Register> getRegisterById(Long registerId) throws RegisterNotFoundException;

public Register updateRegisterById(Long registerId,Register register) throws RegisterNotFoundException;

public void deleteRegisterById(Long registerId) throws RegisterNotFoundException;
public Register registerAssignTicket(Long registerId, Long ticketId);

public List<Register> findAllRegister();


}
