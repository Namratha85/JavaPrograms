package com.edu.vehicle.controller;

import java.util.List;


import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.vehicle.entity.Ticket;
import com.edu.vehicle.error.TicketNotFoundException;
import com.edu.vehicle.service.TicketService;



@RestController //
@CrossOrigin(origins = "http://localhost:4200")
public class TicketController {
	//Inject an object of VehicleService
	@Autowired
	private TicketService ticketService;
	private final Logger LOGGER= LoggerFactory.getLogger(TicketController.class);
	
	//save the record
	                              //post
	/*@PostMapping("/vehicles")  //http://localhost:portno/vehicles
	public Vehicle saveVehicle(@RequestBody Vehicle vehicle) {
		LOGGER.info("Inside saveDept");
		return vehicleService.saveVehicle(vehicle);
	}*/
	@PostMapping("/vehicle")
	public String saveTicket(@RequestBody Ticket ticket) {
		ticketService.saveTicket(ticket);
		return "" +ticket.getMovieName()+" Movie Booked Successfully";
	}
	
	//get  records by id
	
		@GetMapping("/vehicles/{ticketId}") //http://localhost:8889/vehicles/1
		public List<Ticket> getVehicleById(@PathVariable("ticketId") Long ticketId) throws TicketNotFoundException {
			
   return ticketService.getTicketById(ticketId);
		}
		
		//delete
		@DeleteMapping("/vehicles/{ticketId}")
		public String ticketDeleteById(@PathVariable("ticketId") Long ticketId) throws TicketNotFoundException {
			ticketService.ticketDeleteById(ticketId);
			return "Ticket Cancelled";
		}
		
		
		//update 
		@PutMapping("/vehicles/{ticketId}")
		public Ticket ticketUpdateById(@PathVariable("ticketId") Long ticketId,@RequestBody Ticket ticket) throws TicketNotFoundException {
			
			return ticketService.ticketUpdateById(ticketId,ticket);
		}
		//get all vehicles
		@GetMapping("/getAllVehicles")
		public List<Ticket> getAllTickets(){
			return ticketService.getAllTickets();
			
		}
}
	
	
