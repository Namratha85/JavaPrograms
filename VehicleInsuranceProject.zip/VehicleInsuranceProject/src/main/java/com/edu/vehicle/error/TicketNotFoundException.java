package com.edu.vehicle.error;
public class TicketNotFoundException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TicketNotFoundException(String s) {
		super(s);
	}
}

