package com.edu.vehicle.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.vehicle.entity.Register;
import com.edu.vehicle.entity.Ticket;
import com.edu.vehicle.error.RegisterNotFoundException;
import com.edu.vehicle.repository.RegisterRepository;
import com.edu.vehicle.repository.TicketRepository;


@Service
public class RegisterServiceImp implements RegisterService{
    @Autowired
	private RegisterRepository registerRepository;
    @Autowired
    private TicketRepository ticketRepository;
	@Override
	public Register addRegister(Register register) {
		
		return registerRepository.save(register);
	}
	@Override
	public List<Register> getRegisterById(Long registerId) throws RegisterNotFoundException  {
		
		Optional<Register> cus=registerRepository.findById(registerId);
		if(!cus.isPresent()) {
			throw new RegisterNotFoundException("Register Not Found");
		}
		Register cst=registerRepository.findById(registerId).get();
		
		List <Register>l=new ArrayList<>();
		l.add(cst);
		return l;
	}

	@Override
	public Register updateRegisterById(Long customerId, Register register) throws RegisterNotFoundException {
		//get the record from the table
		
		Optional<Register> vle=registerRepository.findById(customerId) ;
		Register vleDB=null;
		if(!vle.isPresent()) {
			 throw new RegisterNotFoundException("Register Not Found");
		}
		
	 else{
			vleDB =registerRepository.findById(customerId).get();
				
				if(Objects.nonNull(register.getrFirstName()) &&
				!"".equalsIgnoreCase(register.getrFirstName())) {
					vleDB.setrFirstName(register.getrFirstName());
				}
				
				if(Objects.nonNull(register.getrLastName()) &&
						!"".equalsIgnoreCase(register.getrLastName())) {
							vleDB.setrLastName(register.getrLastName());
						}
				if(Objects.nonNull(register.getAge())) {
					vleDB.setAge(register.getAge());
				}
				
				if(Objects.nonNull(register.getEmail()) &&
						!"".equalsIgnoreCase(register.getEmail())) {
							vleDB.setEmail(register.getEmail());
						}
				if(Objects.nonNull(register.getRegisterPhone())) {
					vleDB.setRegisterPhone(register.getRegisterPhone());
				}
				
			}//else
		return registerRepository.save(vleDB);
}
	
	@Override
	public void deleteRegisterById(Long customerId) throws RegisterNotFoundException {
Optional<Register> cus=registerRepository.findById(customerId);
		
		if(!cus.isPresent()) {
			throw new RegisterNotFoundException("Customer Id Not present");
		}
		registerRepository.deleteById(customerId);
		}
	
	
	@Override
	public Register registerAssignTicket(Long registerId, Long ticketId) {
		Ticket ticket=ticketRepository.findById(ticketId).get();
		Register register=registerRepository.findById(registerId).get();
		register.registerAssignTicket(ticket);
		return registerRepository.save(register);
	}
	@Override
	public List<Register> findAllRegister() {
		// TODO Auto-generated method stub
		return registerRepository.findAll();
	}
	
}
