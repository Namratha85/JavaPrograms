package com.edu.vehicle.entity;

import javax.persistence.CascadeType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Register {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	private Long registerId;
	@NotBlank(message = "Please enter name")
	
	private String rFirstName;
	private String rLastName;
	private int age;
	@Column(unique=true)
	private String email;
	@Column(unique=true)
	private Long registerPhone;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ticketId",referencedColumnName="ticketId")
	@JsonIgnore
	private Ticket ticket;
	public Ticket getTicket() {
		return ticket;
	}
	
	public void setTicket(Ticket ticket) {
		this.ticket=ticket;
	}

	public Register() {
		super();
	}
	
	public Register(Long registerId, @NotBlank(message = "Please enter name") @Size(min = 4, message = "Name should be atleast 4 characters") @Size(max = 10, message = "Name should not be greater than 10 characters") String rFirstName, String rLastName,
			int age, String email, Long registerPhone) {
		super();
		this.registerId = registerId;
		this.rFirstName = rFirstName;
		this.rLastName = rLastName;
		this.age = age;
		this.email = email;
		this.registerPhone = registerPhone;
	}

	
	public Long getRegisterId() {
		return registerId;
	}

	public void setRegisterId(Long registerId) {
		this.registerId = registerId;
	}

	public String getrFirstName() {
		return rFirstName;
	}

	public void setrFirstName(String rFirstName) {
		this.rFirstName = rFirstName;
	}

	public String getrLastName() {
		return rLastName;
	}

	public void setrLastName(String rLastName) {
		this.rLastName = rLastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getRegisterPhone() {
		return registerPhone;
	}

	public void setRegisterPhone(Long registerPhone) {
		this.registerPhone = registerPhone;
	}

	
	@Override
	public String toString() {
		return "Register [registerId=" + registerId + ", rFirstName=" + rFirstName + ", rLastName=" + rLastName
				+ ", age=" + age + ", email=" + email + ", registerPhone=" + registerPhone + "]";
	}

	public void registerAssignTicket(Ticket ticket) {
		this.ticket=ticket;
		
	}
}